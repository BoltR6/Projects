KNOWN BUGS:
	- Players can use chrome console to just set variables to whatever they want (NOTE: This does not work with recoil, as recoil is generated every time the gun is fired. It DOES work on max ammo though, and probably health.)
	